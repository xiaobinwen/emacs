Major mode for editing JavaScript Object Notation (JSON) data files.
Read more about JSON at http://json.org/.

It provides support for indentation and syntax highlighting.

Thanks to Josh Johnston for writing the original JSON mode!