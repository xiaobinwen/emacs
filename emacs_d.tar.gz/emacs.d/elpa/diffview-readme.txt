Render a unified diff (top/bottom) in an easy-to-comprehend side-by-side
format.  This comes in handy for reading patches from mailing lists (or
from whencever you might acquire them).

Installation:

    M-x package-install diffview